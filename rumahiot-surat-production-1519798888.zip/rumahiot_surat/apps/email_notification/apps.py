from django.apps import AppConfig


class EmailNotificationConfig(AppConfig):
    name = 'email_notification'
