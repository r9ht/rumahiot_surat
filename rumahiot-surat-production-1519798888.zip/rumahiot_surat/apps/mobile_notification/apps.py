from django.apps import AppConfig


class MobileNotificationConfig(AppConfig):
    name = 'mobile_notification'
